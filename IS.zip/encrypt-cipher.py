def caesar_cipher_enc(txt, shift):
    alphabet_lower = "abcdefghijklmnopqrstuvwxyz"
    alphabet_upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    encrypted_text = ""

    for char in txt:
        if char.islower():
            position = alphabet_lower.index(char)
            new_pos = (position + shift) % 26
            encrypted_text += alphabet_lower[new_pos]
        elif char.isupper():
            position = alphabet_upper.index(char)
            new_pos = (position + shift) % 26
            encrypted_text += alphabet_upper[new_pos]
        else:
            encrypted_text += char

    return encrypted_text


if __name__ == "__main__":
    txt = input("Enter a text: ")
    shift = int(input("Enter shift value: "))
    encrypted = caesar_cipher_enc(txt, shift)
    print("Encrypted text:", encrypted)
