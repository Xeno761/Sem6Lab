def rail_fence_enc(txt, depth):
    rail = [['\n' for _ in range(len(txt))] for _ in range(depth)]
    row, step = 0, 1
    
    for i in range(len(txt)):
        rail[row][i] = txt[i]
        if row == 0:
            step = 1
        elif row == depth - 1:
            step = -1
        row += step

    encrypted_text = ''.join(char for row in rail for char in row if char != '\n')
    return encrypted_text

txt = input("Enter text to encrypt: ")
depth = int(input("Enter depth: "))
encrypted = rail_fence_enc(txt, depth)
print("Encrypted text:", encrypted)
