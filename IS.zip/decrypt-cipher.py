def caesar_cipher_dec(txt, shift):
    """
    Decrypts a text using the Caesar cipher.

    Args:
        txt (str): The encrypted text to decrypt.
        shift (int): The shift value (number of positions to shift each character).

    Returns:
        str: The decrypted text.
    """
    alphabet_lower = "abcdefghijklmnopqrstuvwxyz"
    alphabet_upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    decrypted_text = ""

    for char in txt:
        if char.islower():
            position = alphabet_lower.index(char)
            new_pos = (position - shift) % 26
            decrypted_text += alphabet_lower[new_pos]
        elif char.isupper():
            position = alphabet_upper.index(char)
            new_pos = (position - shift) % 26
            decrypted_text += alphabet_upper[new_pos]
        else:
            decrypted_text += char

    return decrypted_text


if __name__ == "__main__":
    txt = input("Enter encrypted text: ")
    shift = int(input("Enter shift value: "))
    decrypted = caesar_cipher_dec(txt, shift)
    print("Decrypted text:", decrypted)
