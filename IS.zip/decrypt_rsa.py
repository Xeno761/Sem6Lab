def decrypt(ciphertext, private_key):
    d, n = private_key
    return ''.join(chr(pow(char, d, n)) for char in ciphertext)

def main():
    private_key = tuple(map(int, input("Enter private key (d, n): ").strip("()").split(",")))
    cipher = list(map(int, input("Enter ciphertext: ").strip("[]").split(",")))
    
    decrypted_message = decrypt(cipher, private_key)
    print("Decrypted Text:", decrypted_message)

if __name__ == "__main__":
    main()
