def rail_fence_dec(enc_txt, depth):
    rail = [['\n' for _ in range(len(enc_txt))] for _ in range(depth)]
    row, step = 0, 1

    for i in range(len(enc_txt)):
        rail[row][i] = '*'
        if row == 0:
            step = 1
        elif row == depth - 1:
            step = -1
        row += step

    index = 0
    for r in range(depth):
        for c in range(len(enc_txt)):
            if rail[r][c] == '*' and index < len(enc_txt):
                rail[r][c] = enc_txt[index]
                index += 1

    result = []
    row, step = 0, 1
    for i in range(len(enc_txt)):
        result.append(rail[row][i])
        if row == 0:
            step = 1
        elif row == depth - 1:
            step = -1
        row += step

    return ''.join(result)

enc_txt = input("Enter text to decrypt: ")
depth = int(input("Enter depth: "))
decrypted = rail_fence_dec(enc_txt, depth)
print("Decrypted text:", decrypted)
